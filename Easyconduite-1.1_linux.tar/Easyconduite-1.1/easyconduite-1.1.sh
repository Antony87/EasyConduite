#!/bin/bash
#########################################################
# This script executes Easyconduite-1.1.
# It supposes that the jar is located within :
# $HOME/Easyconduite-1.1/bin/
#
# Antony Fons 2017
# antony.fons@antonyweb.net
#########################################################

# check for Java 1.8
if ! java -version 2>&1 >/dev/null | grep -q "1.8" ; 
then
	dialog --title "Avertissement" --msgbox "Impossible de lancer Easyconduite-1.1 car Java 1.8 ou sup. n'est pas installé"  10 60
	clear
	exit 0
fi
appliDir=$HOME"/Easyconduite-1.1"

java -Xms512M -Xmx512M -jar $appliDir/bin/easyconduite-1.1-SNAPSHOT.jar &
exit 0
